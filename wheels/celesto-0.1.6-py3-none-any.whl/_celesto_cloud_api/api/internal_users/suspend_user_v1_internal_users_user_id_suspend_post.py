from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.suspend_user_v1_internal_users_user_id_suspend_post_response_suspend_user_v1_internal_users_user_id_suspend_post import (
    SuspendUserV1InternalUsersUserIdSuspendPostResponseSuspendUserV1InternalUsersUserIdSuspendPost,
)
from ...types import UNSET, Unset
from typing import cast


def _get_kwargs(
    user_id: str,
    *,
    x_current_organization: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_current_organization, Unset):
        headers["x-current-organization"] = x_current_organization

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/internal/users/{user_id}/suspend".format(
            user_id=quote(str(user_id), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    HTTPValidationError
    | SuspendUserV1InternalUsersUserIdSuspendPostResponseSuspendUserV1InternalUsersUserIdSuspendPost
    | None
):
    if response.status_code == 200:
        response_200 = SuspendUserV1InternalUsersUserIdSuspendPostResponseSuspendUserV1InternalUsersUserIdSuspendPost.from_dict(
            response.json()
        )

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    HTTPValidationError
    | SuspendUserV1InternalUsersUserIdSuspendPostResponseSuspendUserV1InternalUsersUserIdSuspendPost
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    x_current_organization: str | Unset = UNSET,
) -> Response[
    HTTPValidationError
    | SuspendUserV1InternalUsersUserIdSuspendPostResponseSuspendUserV1InternalUsersUserIdSuspendPost
]:
    """Suspend User

     Suspend a user's access (Super Org only).

    Args:
        user_id (str):
        x_current_organization (str | Unset): Current organization ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SuspendUserV1InternalUsersUserIdSuspendPostResponseSuspendUserV1InternalUsersUserIdSuspendPost]
    """

    kwargs = _get_kwargs(
        user_id=user_id,
        x_current_organization=x_current_organization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    x_current_organization: str | Unset = UNSET,
) -> (
    HTTPValidationError
    | SuspendUserV1InternalUsersUserIdSuspendPostResponseSuspendUserV1InternalUsersUserIdSuspendPost
    | None
):
    """Suspend User

     Suspend a user's access (Super Org only).

    Args:
        user_id (str):
        x_current_organization (str | Unset): Current organization ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SuspendUserV1InternalUsersUserIdSuspendPostResponseSuspendUserV1InternalUsersUserIdSuspendPost
    """

    return sync_detailed(
        user_id=user_id,
        client=client,
        x_current_organization=x_current_organization,
    ).parsed


async def asyncio_detailed(
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    x_current_organization: str | Unset = UNSET,
) -> Response[
    HTTPValidationError
    | SuspendUserV1InternalUsersUserIdSuspendPostResponseSuspendUserV1InternalUsersUserIdSuspendPost
]:
    """Suspend User

     Suspend a user's access (Super Org only).

    Args:
        user_id (str):
        x_current_organization (str | Unset): Current organization ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SuspendUserV1InternalUsersUserIdSuspendPostResponseSuspendUserV1InternalUsersUserIdSuspendPost]
    """

    kwargs = _get_kwargs(
        user_id=user_id,
        x_current_organization=x_current_organization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    user_id: str,
    *,
    client: AuthenticatedClient | Client,
    x_current_organization: str | Unset = UNSET,
) -> (
    HTTPValidationError
    | SuspendUserV1InternalUsersUserIdSuspendPostResponseSuspendUserV1InternalUsersUserIdSuspendPost
    | None
):
    """Suspend User

     Suspend a user's access (Super Org only).

    Args:
        user_id (str):
        x_current_organization (str | Unset): Current organization ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SuspendUserV1InternalUsersUserIdSuspendPostResponseSuspendUserV1InternalUsersUserIdSuspendPost
    """

    return (
        await asyncio_detailed(
            user_id=user_id,
            client=client,
            x_current_organization=x_current_organization,
        )
    ).parsed
