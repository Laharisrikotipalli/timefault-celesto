from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.end_user_list_response import EndUserListResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Unset
from typing import cast


def _get_kwargs(
    *,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_current_organization: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_current_organization, Unset):
        headers["x-current-organization"] = x_current_organization

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/end_users",
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> EndUserListResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = EndUserListResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[EndUserListResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_current_organization: str | Unset = UNSET,
) -> Response[EndUserListResponse | HTTPValidationError]:
    """List end users

     The org's end users, newest first, each with current-window spend.

    ``budget_cap_usd`` is the per-user override only — the effective cap may
    come from the org default, which the detail endpoint reports with its
    source. Keeping the list column literal avoids implying fifty users have
    overrides when one org-level knob is set.

    Args:
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_current_organization (str | Unset): Current organization ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EndUserListResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        limit=limit,
        offset=offset,
        x_current_organization=x_current_organization,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_current_organization: str | Unset = UNSET,
) -> EndUserListResponse | HTTPValidationError | None:
    """List end users

     The org's end users, newest first, each with current-window spend.

    ``budget_cap_usd`` is the per-user override only — the effective cap may
    come from the org default, which the detail endpoint reports with its
    source. Keeping the list column literal avoids implying fifty users have
    overrides when one org-level knob is set.

    Args:
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_current_organization (str | Unset): Current organization ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EndUserListResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        limit=limit,
        offset=offset,
        x_current_organization=x_current_organization,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_current_organization: str | Unset = UNSET,
) -> Response[EndUserListResponse | HTTPValidationError]:
    """List end users

     The org's end users, newest first, each with current-window spend.

    ``budget_cap_usd`` is the per-user override only — the effective cap may
    come from the org default, which the detail endpoint reports with its
    source. Keeping the list column literal avoids implying fifty users have
    overrides when one org-level knob is set.

    Args:
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_current_organization (str | Unset): Current organization ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EndUserListResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        limit=limit,
        offset=offset,
        x_current_organization=x_current_organization,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_current_organization: str | Unset = UNSET,
) -> EndUserListResponse | HTTPValidationError | None:
    """List end users

     The org's end users, newest first, each with current-window spend.

    ``budget_cap_usd`` is the per-user override only — the effective cap may
    come from the org default, which the detail endpoint reports with its
    source. Keeping the list column literal avoids implying fifty users have
    overrides when one org-level knob is set.

    Args:
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_current_organization (str | Unset): Current organization ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EndUserListResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            limit=limit,
            offset=offset,
            x_current_organization=x_current_organization,
        )
    ).parsed
